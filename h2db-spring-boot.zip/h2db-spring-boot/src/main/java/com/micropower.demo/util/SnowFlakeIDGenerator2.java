package com.micropower.demo.util;

import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.net.NetUtil;
import cn.hutool.core.util.IdUtil;
import lombok.extern.slf4j.Slf4j;
/**
 * @description: 雪花算法生成id
 **/
@Slf4j
public class SnowFlakeIDGenerator2 {
    private static long workerId = 0L;  //int类型可以自动转成long类型, 但不能自动转成大写的Long
    private static long datacenterId = 1L;
//    private Snowflake snowflake = IdUtil.createSnowflake(workerId, datacenterId);
    private static Snowflake snowflake = IdUtil.getSnowflake(workerId, datacenterId);

//    static {
//        long workerId;
//        try{
//            workerId = NetUtil.ipv4ToLong(NetUtil.getLocalhostStr());
//            log.info("当前机器的IP： {}, workerId: {}", NetUtil.getLocalhostStr(), workerId);
//        }catch (Exception e) {
//            log.error("获取当前机器workerId 异常", e);
//            workerId = NetUtil.getLocalhostStr().hashCode();
//        }
//        long datacenterId = 1L;
//        snowflake = IdUtil.getSnowflake(workerId, datacenterId);
//
//    }

    public static void main(String[] args) {
        long snowflakeId = getSnowflakeId();
        log.info("" + snowflakeId);
    }
    /**
     * 使用默认的workId 和 datacenterId
     * @return
     */
    public static long getSnowflakeId() {
        return snowflake.nextId();
    }

    /**
     * 使用自定义的workerId 和 datacenter
     * @param workerId
     * @param datacenterId
     * @return
     */
    public synchronized long getSnowflakeId(long workerId, long datacenterId) {
        Snowflake snowflake = IdUtil.getSnowflake(workerId, datacenterId);
        return snowflake.nextId();
    }
}