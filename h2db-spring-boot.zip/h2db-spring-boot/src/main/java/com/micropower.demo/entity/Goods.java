package com.micropower.demo.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@TableName("goods")
public class Goods implements Serializable {
	private static final long serialVersionUID = 1L;

	/** 商品id */
	@TableId
	private Long goodsId;

	/*** 商品名称*/
	private String name;

	/*** 商品编号*/
	private String goodsNo;

	/** 卖家id */
	private Long sellerId;

	/** 所属分类id */
	private Long categoryId;

	private Long createBy;
	private Long updateBy;
	private Date createTime;
	private Date updateTime;

	/** 商品sku */
	private List<Sku> skus;
}
