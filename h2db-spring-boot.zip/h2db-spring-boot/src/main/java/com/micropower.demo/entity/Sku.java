package com.micropower.demo.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@ApiModel("Sku实体模型")
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "sku")
public class Sku implements Serializable {
    private static final long serialVersionUID = 0L;
    /** sku id */
    @TableId
    private Long skuId;

    /*** 规格型号说明 */
    private String specification;

    /*** 商品id*/
    private Long goodsId;

    /*** 价格*/
    private BigDecimal price;

    /** 库存余量 */
    private Long stock;

    /** 库存总量 */
    private Long total;

    private Long createBy;
    private Long updateBy;
    private Date createTime;
    private Date updateTime;
}
