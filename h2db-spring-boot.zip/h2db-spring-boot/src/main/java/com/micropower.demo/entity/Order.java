package com.micropower.demo.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@ApiModel("order实体模型")
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "order")
public class Order implements Serializable {
    private static final long serialVersionUID = 0L;
    /** 订单 id */
    @TableId
    private Long orderId;

    /*** 订单编号 */
    private String orderNo;

    /*** 订单金额 */
    private BigDecimal amount;

    /*** 订单状态 */
    private Integer status;

    /*** 买家id*/
    private Long buyerId;

    /*** 卖家id*/
    private Long sellerId;

    private Long skuId;
    private Integer quantity;

    private Long buyerAccountId;
    private Long sellerAccountId;

    private Long createBy;
    private Long updateBy;
    private Date createTime;
    private Date updateTime;
}
