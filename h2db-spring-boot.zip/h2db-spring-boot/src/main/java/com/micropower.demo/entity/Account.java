package com.micropower.demo.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@ApiModel("account实体模型")
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "account")
public class Account implements Serializable {
    private static final long serialVersionUID = 0L;
    /** 账户 id */
    @TableId
    private Long accountId;

    /*** 用户id*/
    private Long userId;

    /*** 账户编号 */
    private String accountNo;

    /*** 账户余额 */
    private BigDecimal balance;

    /*** 账户名称 */
    private String name;
    private Long createBy;
    private Long updateBy;
    private Date createTime;
    private Date updateTime;
}
