package com.micropower.demo;

import com.alibaba.druid.spring.boot.autoconfigure.DruidDataSourceAutoConfigure;
import io.shardingsphere.shardingjdbc.spring.boot.SpringBootConfiguration;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

//@SpringBootApplication(exclude={DruidDataSourceAutoConfigure.class})

//注意排除的是shardingjdbc里面的shardingjdbc.spring.boot.SpringBootConfiguration
@SpringBootApplication(exclude={SpringBootConfiguration.class})
@MapperScan(basePackages = {"com.micropower.demo.mapper"})
public class DemoApplication {
    public static void main(String[] args) {
        ConfigurableApplicationContext configurableApplicationContext =
                SpringApplication.run(DemoApplication.class, args);
    }
}