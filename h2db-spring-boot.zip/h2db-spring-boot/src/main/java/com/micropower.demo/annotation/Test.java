package com.micropower.demo.annotation;

public class Test {
    public static void main(String[] args){

    }
}
