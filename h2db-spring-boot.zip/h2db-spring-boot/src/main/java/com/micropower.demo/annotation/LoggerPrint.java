package com.micropower.demo.annotation;

import java.lang.annotation.*;

/**
 * 自定义注解，拦截service
 * 注解@Target说明了Annotation所修饰的对象范围
 *
 * 注解@Retention定义了该Annotation被保留的时间长短：
 * 1.SOURCE:在源文件中有效（即源文件保留）
 * 2.CLASS:在class文件中有效（即class保留）
 * 3.RUNTIME:在运行时有效（即运行时保留）
 *
 * 注解@Documented 定义注解会被javadoc或者其他类似工具文档化
 * @author guoxu
 */
//自定义注解描述方法
@Target({ElementType.PARAMETER, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface LoggerPrint {

    /** //注意 注解要放在实现类中 或子类中,放在接口中无效, 子类直接调用父类中带注解的方法, 注解无效
     * 注解后面括号里的参数 @LoggerPrint(description = "xxx")
     */
    String description() default "";
}