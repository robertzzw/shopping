package com.micropower.demo.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.micropower.demo.entity.Goods;
import com.micropower.demo.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;

public interface GoodsService {
    int addGoods(Goods goods);
    List<Goods> findGoodsList();
}
