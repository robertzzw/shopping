package com.micropower.demo.service;


import com.micropower.demo.entity.Goods;
import com.micropower.demo.entity.Order;

import java.util.List;

public interface OrderService {
    int createOrder(Order order);
    void buyGoods(Order order);
}
