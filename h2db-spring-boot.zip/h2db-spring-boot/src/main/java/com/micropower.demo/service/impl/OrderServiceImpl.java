package com.micropower.demo.service.impl;

import com.micropower.demo.entity.Goods;
import com.micropower.demo.entity.Order;
import com.micropower.demo.entity.Sku;
import com.micropower.demo.mapper.GoodsMapper;
import com.micropower.demo.mapper.OrderMapper;
import com.micropower.demo.service.GoodsService;
import com.micropower.demo.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {
    private OrderMapper orderMapper;
    @Autowired
    public void setUserMapper(OrderMapper orderMapper) {
        this.orderMapper = orderMapper;
    }

    private int updateSku(Long skuId, Integer quantity) {
        Integer integer = orderMapper.updateSku(skuId, quantity);
        return integer;
    }

    private int updateAccount(Long accountId, BigDecimal amount) {
        Integer integer = orderMapper.updateAccount(accountId, amount);
        return integer;
    }

    private int payOrder(Order order) {
        Integer integer = orderMapper.updateAccount(order.getBuyerAccountId(), order.getAmount());
        Integer integer2 = orderMapper.updateAccount(order.getSellerAccountId(), order.getAmount().negate());
        return integer;
    }

    @Override
    public int createOrder(Order order) {
        orderMapper.insertOrder(order);
        return 0;
    }
    public int updateOrder(Order order) {
        orderMapper.updateOrder(order);
        return 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void buyGoods(Order order) {
        //1.先扣减库存, 如果库存足够并且能更新成功, 则可以购买
        //高并发下可以做分库分表, 使用RocketMQ, 缓存等应对
        int resutl = updateSku(order.getSkuId(), order.getQuantity());
        if (resutl != 1){
            throw new RuntimeException("扣减库存失败");
        }
        //2.创建订单
        order.setStatus(0);
        createOrder(order);
        //3.支付订单, 更新买家账户余额, 更新卖家账户余额
        payOrder(order);
        //4. 修改订单状态为已支付
        order.setStatus(1);
        updateOrder(order);
    }
}
