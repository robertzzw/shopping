package com.micropower.demo.service.impl;

import com.micropower.demo.entity.Goods;
import com.micropower.demo.entity.Sku;
import com.micropower.demo.mapper.GoodsMapper;
import com.micropower.demo.service.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class GoodsServiceImpl implements GoodsService {
    private GoodsMapper goodsMapper;
    @Autowired
    public void setUserMapper(GoodsMapper goodsMapper) {
        this.goodsMapper = goodsMapper;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int addGoods(Goods goods) {
        Integer result = goodsMapper.insertGoods(goods);
        if (result != 1){
            return -1;
        }
        Long goodsId = goods.getGoodsId();
        List<Sku> skus = goods.getSkus();
        for (Sku sku : skus){
            sku.setGoodsId(goodsId);
        }
        Integer result2 = goodsMapper.insertSkus(skus);
        return 1;
    }

    @Override
    public List<Goods> findGoodsList() {
        List<Goods> goods = goodsMapper.selectGoodsList();
        return goods;
    }
}
