package com.micropower.demo.mapper;

import com.micropower.demo.entity.Goods;
import com.micropower.demo.entity.Order;
import com.micropower.demo.entity.Sku;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Mapper
@Repository
public interface OrderMapper {
    Integer updateSku(@Param("skuId") Long skuId, @Param("quantity") Integer quantity);
    Integer updateAccount(@Param("accounId") Long accounId, @Param("amount") BigDecimal amount);

    Integer insertOrder(@Param("order") Order order);

    void updateOrder(@Param("order") Order order);
}
