package com.micropower.demo.mapper;

import com.micropower.demo.entity.Goods;
import com.micropower.demo.entity.Sku;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface GoodsMapper {
    Integer insertGoods(@Param("goods") Goods goods);
    Integer insertSkus(@Param("skuList") List<Sku> skuList);
    List<Goods> selectGoodsList();
}
