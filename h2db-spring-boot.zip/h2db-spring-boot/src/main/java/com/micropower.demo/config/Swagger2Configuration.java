//package com.micropower.demo.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
//import springfox.documentation.builders.ApiInfoBuilder;
//import springfox.documentation.builders.PathSelectors;
//import springfox.documentation.builders.RequestHandlerSelectors;
//import springfox.documentation.service.ApiInfo;
//import springfox.documentation.service.Contact;
//import springfox.documentation.spi.DocumentationType;
//import springfox.documentation.spring.web.plugins.Docket;
//import springfox.documentation.swagger2.annotations.EnableSwagger2;
//
//@Configuration
//@EnableSwagger2
//public class Swagger2Configuration extends WebMvcConfigurationSupport {
//    @Bean
//    public Docket createRestApi() {
//        ApiInfo apiInfo=new ApiInfoBuilder()
//                .title("用户管理")//api标题
//                .description("用户管理相关接口描述")//api描述
//                .version("1.0.0")//版本号
//                .contact(new Contact("wzz", "baidu", "1729497919@qq.com"))//本API负责人的联系信息
//                .build();
//        return new Docket(DocumentationType.SWAGGER_2)//文档类型（swagger2）
//                .apiInfo(apiInfo)//设置包含在json ResourceListing响应中的api元信息
//                .select()//启动用于api选择的构建器
//                .apis(RequestHandlerSelectors.basePackage("com.micropower.demo.controller"))//扫描接口的包
//                .paths(PathSelectors.any())//路径过滤器（扫描所有路径）
//                .build();
//    }
//    @Override
//    protected void addResourceHandlers(ResourceHandlerRegistry registry) {
//        // 解决静态资源无法访问
//        registry.addResourceHandler("/**")
//                .addResourceLocations("classpath:/static/");
//        // 解决swagger无法访问
//        registry.addResourceHandler("/swagger-ui.html")
//                .addResourceLocations("classpath:/META-INF/resources/");
//        // 解决swagger的js文件无法访问
//        registry.addResourceHandler("/webjars/**")
//                .addResourceLocations("classpath:/META-INF/resources/webjars/");
//    }
//
//    //    @Bean
////    public Docket accessToken() {
////        return new Docket(DocumentationType.SWAGGER_2)
////                .groupName("api")// 定义组
////                .select() // 选择那些路径和 api 会生成 document
////                .apis(RequestHandlerSelectors.basePackage("com.micropower.demo.controller")) // 拦截的包路径
////                .paths(regex("/api/.*"))// 拦截的接口路径
////                .build() // 创建
////                .apiInfo(apiInfo()); // 配置说明
////    }
//
//    // swagger2的配置文件，这里可以配置swagger2的一些基本的内容，比如扫描的包等等
////    @Bean
////    public Docket createRestApi() {
////        return new Docket(DocumentationType.SWAGGER_2)
////                .apiInfo(apiInfo())
////                .select()
////                // 为当前包路径
////                .apis(RequestHandlerSelectors.basePackage("cn.xdf.springboot.controller"))
////                .paths(PathSelectors.any())
////                .build();
////    }
//    // 构建 api文档的详细信息函数,注意这里的注解引用的是哪个
////    private ApiInfo apiInfo() {
////        return new ApiInfoBuilder()
////                // 页面标题
////                .title("Spring Boot 测试使用 Swagger2 构建RESTful API")
////                // 创建人信息
////                .contact(new Contact("MrZhang",
////                "https://www.cnblogs.com/zs-notes/category/1258467.html",  "1729497919@qq.com"))
////                // 版本号
////                .version("1.0")
////                // 描述
////                .description("API 描述")
////                .build();
////    }
//}