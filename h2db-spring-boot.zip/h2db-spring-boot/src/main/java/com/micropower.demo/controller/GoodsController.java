package com.micropower.demo.controller;

import com.micropower.demo.entity.Goods;
import com.micropower.demo.service.GoodsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "测试接口", tags = "商品模块服务", description = "用户测试接口")
@RestController
@RequestMapping("/goods")
public class GoodsController {
    @Autowired
    private GoodsService goodsService;

    @ApiOperation(value = "查询商品列表, 包含该商品的sku,一对多查询")
    @GetMapping("/findGoodsList")
    public List<Goods> findGoodsList(){
        return goodsService.findGoodsList();
    }

    @ApiOperation(value = "添加商品, 包含该商品的sku,一对多插入")
    @PostMapping("/addGoods")
    public String addGoods(@RequestBody Goods goods){
        int result = goodsService.addGoods(goods);
        if (result != 1){
            return "添加失败";
        }
        return "添加成功";
    }
}
