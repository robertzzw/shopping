package com.micropower.demo.controller;

import com.micropower.demo.entity.Goods;
import com.micropower.demo.entity.Order;
import com.micropower.demo.service.GoodsService;
import com.micropower.demo.service.OrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "测试接口", tags = "订单模块服务", description = "用户测试接口")
@RestController
@RequestMapping("/order")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @ApiOperation(value = "下单购买商品")
    @PostMapping("/buyGoods")
    public String buyGoods(@RequestBody Order order){
        orderService.buyGoods(order);
        return "下单成功";
    }
}
