
-- 脚本文件不能为空, 否则报错'script' must not be null or empty
insert into `goods` values
    (1, '华为手机', 'mate60', 3, 1, 3355, 3355, current_timestamp(), current_timestamp()),
    (2, '华为手机', 'p10', 3, 1, 3355, 3355, current_timestamp(), current_timestamp()),
    (3, '小米手机', 'xiaomi12', 5, 1, 3355, 3355, current_timestamp(), current_timestamp());

insert into `sku` values
    (1, '白色型号', 1, 6000.00, 100, 300, 3355, 3355, current_timestamp(), current_timestamp()),
    (2, '黑色型号', 1, 5000.00, 50, 300, 3355, 3355, current_timestamp(), current_timestamp()),
    (3, '蓝色型号', 1, 5000.00, 10, 300, 3355, 3355, current_timestamp(), current_timestamp());

insert into user values
    (3355, 'seller01', '12345678999', '深圳',  3355, 3355, current_timestamp(), current_timestamp()),
     (3356, 'buyer01', '12345678999', '深圳',  3356, 3356, current_timestamp(), current_timestamp());

insert into account values
    (1, 3355, '888999', 100000.00, 'seller01 account ',  3355, 3355, current_timestamp(), current_timestamp()),
    (2, 3356, '333666', 100000.00, 'buyer01 account ',  3356, 3356, current_timestamp(), current_timestamp());
