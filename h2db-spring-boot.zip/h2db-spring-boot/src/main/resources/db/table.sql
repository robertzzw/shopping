-- 不使用业务唯一性字段做主键的原因:
-- 主键上一般默认是高效的聚簇的索引,主键适合采用整型数据类型, 效率会比较高, 表之间优先使用主键进行关联
-- 而业务字段通常是字符串类型, 比整型效率低, 有可能需要修改的风险,
-- 如果用业务字段做主键, 一旦发生修改,维护成本非常高,
-- 业务编号一般由一定规则生成,或自定义, 有一定的含义, 容易看懂识别,
-- 比如订单编号, 学号, 身份证号等, 虽然具有唯一性, 但不适合做主键

-- 商品信息表, 即SPU(Standard Product Unit)标准化产品单位
drop table if exists `goods`;
create table `goods` (
  `goods_id` bigint(20) not null auto_increment comment '商品id',
  `name` varchar(50) not null comment '商品名称',
  `goods_no` varchar(32) not null comment '商品编号',
  `seller_id` bigint(20) not null comment '卖家id, 一个卖家可以卖多个商品',
  `category_id` bigint(20) default null comment '商品分类id',
  `create_by` bigint(20) unsigned not null comment '创建人id',
  `update_by` bigint(20) unsigned default null comment '修改人id',
  `create_time` timestamp not null default current_timestamp comment '创建时间',
  `update_time` timestamp not null default '0000-00-00 00:00:00' on update current_timestamp comment '更新时间',
  primary key (`goods_id`),
  unique key `goods_no` (`goods_no`)
);

-- 商品规格型号表/不同型号库存表, (stock keeping unit)即库存量单位
drop table if exists sku;
create table if not exists `sku` (
 `sku_id` bigint(20) primary key auto_increment comment 'sku id',
 `specification` varchar(100) comment '商品规格型号,如有较多不同规格,可以再扩展一张子表',
 `goods_id` bigint(20) not null comment '商品id, 一个商品有多个sku',
 `price` decimal(10,2) unsigned not null default '0.00' comment '商品价格/某个型号的价格',
 `stock` bigint(20) unsigned not null default '0' comment '商品库存剩余数量',
 `total` bigint(20) unsigned not null default '0' comment '商品库存总数量',
 `create_by` bigint(20) unsigned not null comment '创建人id',
 `update_by` bigint(20) unsigned comment '修改人id',
 `create_time` timestamp not null default current_timestamp comment '创建时间',
 `update_time` timestamp on update current_timestamp comment '更新时间'
);

drop table if exists `user`;
create table `user` (
 `user_id` bigint(20) primary key auto_increment comment '用户id',
 `name` varchar(50) not null comment '用户名称',
 `cellphone` char(11) comment '手机号码',
 `address` varchar(100) comment '用户地址',
 `create_by` bigint(20) unsigned not null comment '创建人id',
 `update_by` bigint(20) unsigned comment '修改人id',
 `create_time` timestamp not null default current_timestamp comment '创建时间',
 `update_time` timestamp on update current_timestamp comment '更新时间'
);

drop table if exists `account`;
create table `account` (
 `account_id` bigint(20) primary key auto_increment comment '账户id',
 `user_id` bigint(20) comment '用户id',
 `account_no` varchar(50) unique not null comment '账户编号',
 `balance` decimal(10,2) unsigned not null default '0.00' comment '账户余额',
 `name` varchar(50) comment '账户名称',
 `create_by` bigint(20) unsigned not null comment '创建人id',
 `update_by` bigint(20) unsigned comment '修改人id',
 `create_time` timestamp not null default current_timestamp comment '创建时间',
 `update_time` timestamp on update current_timestamp comment '更新时间'
);

-- 订单表
drop table if exists `order`;
create table `order` (
 `order_id` bigint(20) primary key auto_increment,
 `order_no` varchar(100) unique not null comment '订单编号',
 `amount` decimal(10,2) unsigned not null default '0.00' comment '订单金额,数量',
 `status` int(11) default 0 comment '订单状态, 0未支付, 1已支付',
 `buyer_id` bigint(20) not null comment '买家id',
 `seller_id` bigint(20) not null comment '卖家id',
 `create_by` bigint(20)  not null comment '创建人id',
 `update_by` bigint(20) comment '修改人id',
 `create_time` timestamp not null default current_timestamp comment '创建时间',
 `update_time` timestamp on update current_timestamp comment '更新时间'
);

-- 订单详情表
